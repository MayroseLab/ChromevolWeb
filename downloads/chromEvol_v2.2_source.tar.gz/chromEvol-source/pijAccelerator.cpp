// $Id: pijAccelerator.cpp 962 2006-11-07 15:13:34Z privmane $

#include "pijAccelerator.h"

pijAccelerator::~pijAccelerator(){}
// this must be here. see Effective c++ page 63 (item 14, constructors, destructors, 
// assignment


